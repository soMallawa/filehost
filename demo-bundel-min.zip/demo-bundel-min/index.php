<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ADB We-Fi Learning</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700&display=swap" rel="stylesheet">



  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">

</head>

<body>  
  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top bg-custom-navbar">
    <div class="container">
      <a class="navbar-brand" href="#">
        
          <img class="nav-logo" src="/assets/images/logo.jpg" width="60" height="50" alt="">
      </a>
     
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/moodle">News</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
          <li class="nav-item" style="padding-left: 20px;">
            <a type="button" class="btn btn-primary" href="/moodle/login/signup.php"><i class="fa fa-user-plus"></i>&nbsp;&nbsp;<b>REGISTER</a></button>
          </li>
         
      <li class="nav-item dropdown" style="padding-left: 5px;"> 
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-cog text-white cog" style="opacity: 0.8;"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="#">1 Column Portfolio</a>
              <a class="dropdown-item" href="#">2 Column Portfolio</a>
              <a class="dropdown-item" href="#">3 Column Portfolio</a>
              <a class="dropdown-item" href="#">4 Column Portfolio</a>
              <a class="dropdown-item" href="#">Single Portfolio Item</a>
            </div>
        </li>
          
        
        </ul>
      </div>
    </div>
  </nav>

  <header>
   <!----> 
   <div class="jumbotron text-white text-center" >
     
     <div class="row mb-3 mt-3">
       <div class="col-lg-10 jumbo-shader mx-auto">
          
              <h1 class="display-4">ADB We-Fi Portal</h1>
              <p class="lead">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam.</p>
              <div class="mt-5">
                <p>Please login to view online course content.</p>
                <p class="lead">
                  <a class="btn btn-custom btn-primary btn-lg text-uppercase"  href="/moodle/login" role="button"><i class="fa fa-user"></i>&nbsp;&nbsp;Portal Login</a>
                </p>
              </div>
              
            
       </div>
     </div>
   
    
  </div>
  </header>

  <!-- Page Content -->
  <div class="container">

   

    <!-- Portfolio Section -->
    <!--<h2>Portfolio Heading</h2>-->
    <div class="row mb-5">
      <div class="col-md-10 mx-auto text-center">
        <h2 class="gradient-h mt-4 " style=" color: gray; padding-bottom: 6px;">About Us</h2>
        <!-- <div class="gradient-h">&nbsp;</div> -->
        <p style="padding-top:20px" class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <!-- <img src="/assets/images/about.png" class="img-fluid" style="height:auto; width: auto;" alt="Responsive image"> -->
        
      </div>
      
    </div>
    <div class="row mb-5 ">
      <div class="col-lg-4">
        <div class="card lead-card mb-3 ">
          <div class="card-body text-center">
            <div class="lead-icon-div">
                <center><i class="fa fa-users fa-3x lead-icon"></i></center>
            </div>
            <h6 class="lead-h" >Lorem ipsum dolor</h6>    
            <p class="text-muted"> <strong></strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident</p>
          </div>
          <i class="fa fa-users card-bg-icon"></i>
        </div>
      </div>
      <div class="col-lg-4">
          <div class="card lead-card mb-3 ">
            <div class="card-body text-center">
              <div class="lead-icon-div">
                  <center><i class="fa fa-building fa-3x lead-icon"></i></center>
              </div>
              <h6 class="lead-h" >Lorem ipsum dolor</h6>    
              <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident</p>
            </div>
            <i class="fa fa-building card-bg-icon"></i>
          </div>
      </div>
      <div class="col-lg-4">
          <div class="card lead-card mb-3 ">
            <div class="card-body text-center">
              <div class="lead-icon-div">
                  <center><i class="fa fa-rocket fa-3x lead-icon"></i></center>
              </div>
              <h6 class="lead-h" >Lorem ipsum dolor</h6>    
              <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident</p>
            </div>
            <i class="fa fa-rocket card-bg-icon"></i>
          </div>
      </div>
    </div>
  

   

    <!-- Features Section -->
    <div class="row mb-5">
      <div class="col-lg-6 text-center">
        <h2 class="gradient-h mb-5" style="color: gray; padding-bottom: 6px;">Entrepreneurs</h2>
        <p class="lead mb-3" >Whether you are simply exploring being an entrepreneur, have just started off with your business, or have an established enterprise, this platform is for you!</p>
        <button type="button" class="btn btn-outline-primary"><i class="fa fa-envelope-open" aria-hidden="true"></i>&nbsp;&nbsp;APPLY</button>
        
      </div>
      <div class="col-lg-6 mt-4">
        <img class="img-fluid rounded" src="assets/images/entp.svg" alt="">
      </div>
    </div>
    <div class="row mb-5 mt-3">
        <div class="col-lg-6 ">
            <img class="img-fluid rounded" src="assets/images/pat.svg" alt="">
          
        </div>
        <div class="col-lg-6 text-center">
            <h2 class="gradient-h mb-5 mt-4" style="color: gray; padding-bottom: 6px;">Mentors</h2>
            <p class="lead" >Whether you are simply exploring being an entrepreneur, have just started off with your business, or have an established enterprise, this platform is for you!</p>
            <button type="button" class="btn btn-outline-primary"><i class="fa fa-envelope-open" aria-hidden="true"></i>&nbsp;&nbsp;APPLY</button>
          </div>
      </div>
    
    <!-- <div class="row">
      
      <div class="col-lg-12">
          <center><h2 class="gradient-h mb-5 mt-4" style="color: gray; padding-bottom: 6px;">News Events</h2></center>
          <div class="card mb-4">
              <div class="card-body">
                <div class="row">
                  <div class="col-lg-6">
                    <a href="#">
                      <img class="img-fluid rounded" src="https://picsum.photos/750/300?random&random=1" alt="">
                    </a>
                  </div>
                  <div class="col-lg-6">
                    <h4 class="card-title post-title">Post Title</h4>
                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla? Quos cum ex quis soluta, a laboriosam. Dicta expedita corporis animi vero voluptate voluptatibus possimus, veniam magni quis!</p>
                    <a href="#" class="btn btn-primary">Read More &rarr;</a>
                  </div>
                </div>
              </div>
              <div class="card-footer text-muted">
                Posted on January 1, 2017 by
                <a href="#">Username</a>
              </div>
            </div>
            <div class="card mb-4">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-6">
                      <a href="#">
                        <img class="img-fluid rounded" src="https://picsum.photos/750/300" alt="">
                      </a>
                    </div>
                    <div class="col-lg-6">
                      <h4 class="card-title post-title">Post Title</h4>
                      <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla? Quos cum ex quis soluta, a laboriosam. Dicta expedita corporis animi vero voluptate voluptatibus possimus, veniam magni quis!</p>
                      <a href="#" class="btn btn-primary">Read More &rarr;</a>
                    </div>
                  </div>
                </div>
                <div class="card-footer text-muted">
                  Posted on January 1, 2017 by
                  <a href="#">Username</a>
                </div>
            </div>
                
    <ul class="pagination justify-content-center mb-4">
        <li class="page-item">
          <a class="page-link" href="#">&larr; Older</a>
        </li>
        <li class="page-item disabled">
          <a class="page-link" href="#">Newer &rarr;</a>
        </li>
      </ul>
            
            
        </div>
    </div>-->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="js/custom.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
