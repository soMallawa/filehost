<?php
    require("db.inc.php");

    if(isset($_GET["id"]) && $_GET["id"] > 0) {
    
        $story_id = $_GET["id"];
        
        $sqlstmt = $conn->prepare("SELECT * FROM wefi_tools_formats WHERE tool_cat_id=?");
        $sqlstmt->bind_param("i", $story_id);
        
    } else {
        if(isset($_GET["q"])) {
          $search_q = '%' . $_GET["q"] . '%';
          $sqlstmt = $conn->prepare("SELECT * FROM wefi_tools_formats WHERE tool_title LIKE ?");
          $sqlstmt->bind_param("s", $search_q);
          
        } else {
          $sqlstmt = $conn->prepare("SELECT * FROM wefi_tools_formats");
          //echo 'hello';
        }
        
    }   
    
    

    
    $sqlstmt->execute();
    
    $result = $sqlstmt->get_result();
    $tfitems = array();

    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) { 
            $tfitems[] = $row;
        }

    }
    
    echo json_encode($tfitems);