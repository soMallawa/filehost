<?php
    require("db.inc.php");

    if(isset($_GET["id"]) && $_GET["id"] > 0) {
        $story_id = $_GET["id"];
        $sqlstmt = $conn->prepare("SELECT * FROM wefi_learning_materials_cat WHERE id=?");
        $sqlstmt->bind_param("i", $story_id);
    } else {
        $sqlstmt = $conn->prepare("SELECT * FROM wefi_learning_materials_cat");

    }   

    
    $sqlstmt->execute();
    
    $result = $sqlstmt->get_result();
    $lmats = array();

    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) { 
            $lmats[] = $row;
        }

    }
    
    echo json_encode($lmats);