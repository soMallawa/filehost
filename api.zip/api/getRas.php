<?php
    require("db.inc.php");


        if(isset($_GET["q"])) {
          $search_q = '%' . $_GET["q"] . '%';
          $sqlstmt = $conn->prepare("SELECT * FROM wefi_reports_arti WHERE ra_title LIKE ?");
          $sqlstmt->bind_param("s", $search_q);
          
        } else {
          $sqlstmt = $conn->prepare("SELECT * FROM wefi_reports_arti");
          //echo 'hello';
        }

    
    

    
    $sqlstmt->execute();
    
    $result = $sqlstmt->get_result();
    $raitems = array();

    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) { 
            $raitems[] = $row;
        }

    }
    
    echo json_encode($raitems);