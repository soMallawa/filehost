<?php
    require("db.inc.php");


        
    $sqlstmt = $conn->prepare("SELECT * FROM wefi_links ORDER BY link_name");


    
    

    
    $sqlstmt->execute();
    
    $result = $sqlstmt->get_result();
    $raitems = array();

    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) { 
            $raitems[] = $row;
        }

    }
    
    echo json_encode($raitems);