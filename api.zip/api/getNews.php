<?php
    require("db.inc.php");

    if(isset($_GET["id"]) && $_GET["id"] > 0) {
        $story_id = $_GET["id"];
        $sqlstmt = $conn->prepare("SELECT * FROM wefi_news WHERE id=?");
        $sqlstmt->bind_param("i", $story_id);
    } else {
        $sqlstmt = $conn->prepare("SELECT * FROM wefi_news ORDER BY id DESC");
    }   

    
    $sqlstmt->execute();
    
    $result = $sqlstmt->get_result();
    $news = array();

    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) { 
            $news[] = $row;
        }

    }
    
    echo json_encode($news);