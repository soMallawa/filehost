<?php
    require("db.inc.php");

    if(isset($_GET["id"]) && $_GET["id"] > 0) {
    
        //$course_id = $_GET["id"];
        
        //$sqlstmt = $conn->prepare("SELECT * FROM wefi_learning_materials WHERE material_cat_id=?");
        //$sqlstmt->bind_param("i", $story_id);
        
    } else {
        if(isset($_GET["q"])) {
          $search_q = '%' . $_GET["q"] . '%';
          $sqlstmt = $conn->prepare("SELECT * FROM wefi_courses WHERE course_title LIKE ?");
          $sqlstmt->bind_param("s", $search_q);
          
        } else {
          $sqlstmt = $conn->prepare("SELECT * FROM wefi_courses");
          //echo 'hello';
        }
        
    }   
    
    

    
    $sqlstmt->execute();
    
    $result = $sqlstmt->get_result();
    $lmats = array();

    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) { 
            $lmats[] = $row;
        }

    }
    
    echo json_encode($lmats);