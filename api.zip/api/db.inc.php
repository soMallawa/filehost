<?php
  $db_servername = "localhost";
  $db_username = "oldapi";
  $db_password = "oldapialt@1234";
  $db_name = "wefi_front";

  // Create connection
  $conn = mysqli_connect($db_servername, $db_username, $db_password, $db_name);

  // Check connection
  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
  // Headers
  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Methods: GET, POST");
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
?>