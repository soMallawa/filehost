<?php
    require("db.inc.php");

    if(isset($_GET["id"]) && $_GET["id"] > 0) {
        $story_id = $_GET["id"];
        $sqlstmt = $conn->prepare("SELECT * FROM wefi_success_stories WHERE id=?");
        $sqlstmt->bind_param("i", $story_id);
    } else {
        $sqlstmt = $conn->prepare("SELECT * FROM wefi_success_stories");
    }   

    
    $sqlstmt->execute();
    
    $result = $sqlstmt->get_result();
    $stories = array();

    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) { 
            $stories[] = $row;
        }

    }
    
    echo json_encode($stories);